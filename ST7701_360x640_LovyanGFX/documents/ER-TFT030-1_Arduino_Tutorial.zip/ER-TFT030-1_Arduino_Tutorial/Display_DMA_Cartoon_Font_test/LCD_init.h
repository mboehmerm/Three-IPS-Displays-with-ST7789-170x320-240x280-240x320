#ifndef LCD_init_h
#define LCD_init_h
#include "Arduino.h"
//#include <avr/pgmspace.h>
#include <SPI.h>

#define  SPI_CS     2
#define  SPI_CLK    1  // DUE   13
#define  SPI_DI     0 //  DUE   11 


#define  SPI_CS_RES   digitalWrite(SPI_CS, LOW)
#define  SPI_CS_SET   digitalWrite(SPI_CS, HIGH)
#define  SPI_CLK_RES   digitalWrite(SPI_CLK, LOW)
#define  SPI_CLK_SET   digitalWrite(SPI_CLK, HIGH)
#define  SPI_DI_RES   digitalWrite(SPI_DI, LOW)
#define  SPI_DI_SET   digitalWrite(SPI_DI, HIGH)



void HW_SPI_Send(unsigned char i)
{ 
  SPI.transfer( i);
}




//RGB+9b_SPI(rise)
 void SW_SPI_Send(unsigned char i)
{  
   unsigned char n;
   
   for(n=0; n<8; n++)			
   {       
			SPI_CLK_RES;
			if(i&0x80)SPI_DI_SET ;
                        else SPI_DI_RES ;

			SPI_CLK_SET;

			i<<=1;
	  
   }
}

void SPI_WriteComm(unsigned char i)
{
    SPI_CS_RES;
    SPI_DI_RES;//DI=0 COMMAND
 
    SPI_CLK_RES;
    SPI_CLK_SET;
  //  HW_SPI_Send(i);
    SW_SPI_Send(i);	
    SPI_CS_SET;	
}



void SPI_WriteData(unsigned char i)
{ 
    SPI_CS_RES;
    SPI_DI_SET;//DI=1 DATA
    SPI_CLK_RES;
    SPI_CLK_SET;
  //  HW_SPI_Send(i);   
    SW_SPI_Send(i);
    SPI_CS_SET;  		
} 

void ST7701S_Initial(void)
{  
     pinMode(SPI_CS,   OUTPUT);
    digitalWrite(SPI_CS, HIGH);
    pinMode(SPI_CLK,   OUTPUT);
    digitalWrite(SPI_CLK, LOW);
    pinMode(SPI_DI,   OUTPUT);
    digitalWrite(SPI_DI, LOW);  

	SPI_WriteComm(0x11);
	delay(120);
	
	SPI_WriteComm(0xFF);
	SPI_WriteData(0x77);
	SPI_WriteData(0x01);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x10);
	
	
	SPI_WriteComm(0xC0);
	SPI_WriteData(0x4F);
	SPI_WriteData(0x00);
	
	
	SPI_WriteComm(0xC1);
	SPI_WriteData(0x07);
	SPI_WriteData(0x02);
	
	
	SPI_WriteComm(0xC2);
	SPI_WriteData(0x31);
	SPI_WriteData(0x05);
	
	SPI_WriteComm(0xC3);
	SPI_WriteData(0x80);
	SPI_WriteData(0x02);
	SPI_WriteData(0x07);	

	SPI_WriteComm(0xCC);
	SPI_WriteData(0x10);	
	
	SPI_WriteComm(0xB0);
	SPI_WriteData(0x00);
	SPI_WriteData(0x0A);
	SPI_WriteData(0x11);
	SPI_WriteData(0x0C);
	SPI_WriteData(0x10);
	SPI_WriteData(0x05);
	SPI_WriteData(0x00);
	SPI_WriteData(0x08);
	SPI_WriteData(0x08);
	SPI_WriteData(0x1F);
	SPI_WriteData(0x07);
	SPI_WriteData(0x13);
	SPI_WriteData(0x10);
	SPI_WriteData(0xA9);
	SPI_WriteData(0x30);
	SPI_WriteData(0x18);
	SPI_WriteComm(0xB1);
	SPI_WriteData(0x00);
	SPI_WriteData(0x0B);
	SPI_WriteData(0x11);
	SPI_WriteData(0x0D);
	SPI_WriteData(0x0F);
	SPI_WriteData(0x05);
	SPI_WriteData(0x02);
	SPI_WriteData(0x07);
	SPI_WriteData(0x06);
	SPI_WriteData(0x20);
	SPI_WriteData(0x05);
	SPI_WriteData(0x15);
	SPI_WriteData(0x13);
	SPI_WriteData(0xA9);
	SPI_WriteData(0x30);
	SPI_WriteData(0x18);
	SPI_WriteComm(0xFF);
	SPI_WriteData(0x77);
	SPI_WriteData(0x01);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x11);
	
	
	SPI_WriteComm(0xB0);
	SPI_WriteData(0x53);
	SPI_WriteComm(0xB1);
	SPI_WriteData(0x60);
	
	SPI_WriteComm(0xB2);
	SPI_WriteData(0x07);
	
	SPI_WriteComm(0xB3);
	SPI_WriteData(0x80);
	
	SPI_WriteComm(0xB5);
	SPI_WriteData(0x49);
	
	SPI_WriteComm(0xB7);
	SPI_WriteData(0x85);
	
	SPI_WriteComm(0xB8);
	SPI_WriteData(0x21);
	
	SPI_WriteComm(0xC1);
	SPI_WriteData(0x78);
	
	SPI_WriteComm(0xC2);
	SPI_WriteData(0x78);
	delay(100);
	
	SPI_WriteComm(0xE0);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x02);
	
	SPI_WriteComm(0xE1);
	SPI_WriteData(0x03);
	SPI_WriteData(0xA0);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x02);
	SPI_WriteData(0xA0);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x33);
	SPI_WriteData(0x33);
	SPI_WriteComm(0xE2);
	SPI_WriteData(0x22);
	SPI_WriteData(0x22);
	SPI_WriteData(0x33);
	SPI_WriteData(0x33);
	SPI_WriteData(0x88);
	SPI_WriteData(0xA0);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x87);
	SPI_WriteData(0xA0);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	
	
	SPI_WriteComm(0xE3);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x22);
	SPI_WriteData(0x22);
	
	SPI_WriteComm(0xE4);
	SPI_WriteData(0x44);
	SPI_WriteData(0x44);
	
	SPI_WriteComm(0xE5);
	SPI_WriteData(0x04);
	SPI_WriteData(0x84);
	SPI_WriteData(0xA0);
	SPI_WriteData(0xA0);
	SPI_WriteData(0x06);
	SPI_WriteData(0x86);
	SPI_WriteData(0xA0);
	SPI_WriteData(0xA0);
	SPI_WriteData(0x08);
	SPI_WriteData(0x88);
	SPI_WriteData(0xA0);
	SPI_WriteData(0xA0);
	SPI_WriteData(0x0A);
	SPI_WriteData(0x8A);
	SPI_WriteData(0xA0);
	SPI_WriteData(0xA0);
	
	SPI_WriteComm(0xE6);
	SPI_WriteData(0x00);
	SPI_WriteData(0x00);
	SPI_WriteData(0x22);
	SPI_WriteData(0x22);
	
	SPI_WriteComm(0xE7);
	SPI_WriteData(0x44);
	SPI_WriteData(0x44);
	
	SPI_WriteComm(0xE8);
	SPI_WriteData(0x03);
	SPI_WriteData(0x83);
	SPI_WriteData(0xA0);
	SPI_WriteData(0xA0);
	SPI_WriteData(0x05);
	SPI_WriteData(0x85);
	SPI_WriteData(0xA0);
	SPI_WriteData(0xA0);
	SPI_WriteData(0x07);
	SPI_WriteData(0x87);
	SPI_WriteData(0xA0);
	SPI_WriteData(0xA0);
	SPI_WriteData(0x09);
	SPI_WriteData(0x89);
	SPI_WriteData(0xA0);
	SPI_WriteData(0xA0);
	
	SPI_WriteComm(0xEB);
	SPI_WriteData(0x00);
	SPI_WriteData(0x01);
	SPI_WriteData(0xE4);
	SPI_WriteData(0xE4);
	SPI_WriteData(0x88);
	SPI_WriteData(0x00);
	SPI_WriteData(0x40);
	
	SPI_WriteComm(0xEC);
	SPI_WriteData(0x3C);
	SPI_WriteData(0x01);
	
	SPI_WriteComm(0xED);
	SPI_WriteData(0xAB);
	SPI_WriteData(0x89);
	SPI_WriteData(0x76);
	SPI_WriteData(0x54);
	SPI_WriteData(0x02);
	SPI_WriteData(0xFF);
	SPI_WriteData(0xFF);
	SPI_WriteData(0xFF);
	SPI_WriteData(0xFF);
	SPI_WriteData(0xFF);
	SPI_WriteData(0xFF);
	SPI_WriteData(0x20);
	SPI_WriteData(0x45);
	SPI_WriteData(0x67);
	SPI_WriteData(0x98);
	SPI_WriteData(0xBA);	 

	
	SPI_WriteComm(0x3A);
	SPI_WriteData(0x66);

	SPI_WriteComm(0x36);
	SPI_WriteData(0x00);
	
	delay(100);
	SPI_WriteComm(0x29); 
  


}

#endif


